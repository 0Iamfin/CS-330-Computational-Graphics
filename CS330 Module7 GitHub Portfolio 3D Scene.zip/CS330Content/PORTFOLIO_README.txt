SNHU CS 330 - Module Seven 3D Scene Portfolio Artifact

This is the trimmed portfolio copy of the user's Module Seven project.
It contains the actual uploaded final project source code, Visual Studio 2022
solution and project file, Windows Release EXE and glew32.dll, shader files,
3D mesh code, and required OpenGL libraries and headers.

IMPORTANT: Open Projects/7-1_FinalProjectMilestones/7-1_FinalProjectMilestones.sln
in Visual Studio 2022. Select Release | x86 to rebuild. To run the application,
use the project working directory (the directory containing the textures folder)
or open the solution and run the project in Visual Studio.

The textures have been re-encoded as JPEG at the ORIGINAL 4096 x 4096
resolution at good visual quality to enable GitHub's browser file limit.
No source code edits or rebuilding have been performed to create this ZIP.
Windows executable has been preserved from user's Release build, but it
cannot be executed/tested in the Linux packaging environment.

This portfolio ZIP intentionally excludes older course assignments, duplicated
ZIP files, Visual Studio cache (.vs) and intermediate .obj/.pdb/.ilk files,
optional unused textures, documentation for dependencies, and old executables.
