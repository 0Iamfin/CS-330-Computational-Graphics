///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ===============
// manage the viewing of 3D objects within the viewport
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_transform.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// variables used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// false represents perspective projection
	// true represents orthographic projection
	bool bOrthographicProjection = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	// create the camera
	g_pCamera = new Camera();

	// default camera view parameters
	g_pCamera->Position =
		glm::vec3(0.0f, 5.0f, 12.0f);

	g_pCamera->Front =
		glm::vec3(0.0f, -0.5f, -2.0f);

	g_pCamera->Up =
		glm::vec3(0.0f, 1.0f, 0.0f);

	g_pCamera->Zoom = 80;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	// free allocated camera memory
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  Creates the OpenGL display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
	const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// create the GLFW window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL,
		NULL);

	if (window == NULL)
	{
		std::cout
			<< "Failed to create GLFW window"
			<< std::endl;

		glfwTerminate();

		return NULL;
	}

	// make this window the active OpenGL context
	glfwMakeContextCurrent(window);

	// receive mouse movement events
	glfwSetCursorPosCallback(
		window,
		&ViewManager::Mouse_Position_Callback);

	// receive mouse scroll events
	glfwSetScrollCallback(
		window,
		&ViewManager::Mouse_Scroll_Callback);

	// This can be enabled if the cursor should stay
	// captured inside the OpenGL window.
	// glfwSetInputMode(
	//	window,
	//	GLFW_CURSOR,
	//	GLFW_CURSOR_DISABLED);

	// enable blending for transparent rendering
	glEnable(GL_BLEND);

	glBlendFunc(
		GL_SRC_ALPHA,
		GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return window;
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  Uses mouse movement to change camera orientation.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window,
	double xMousePos,
	double yMousePos)
{
	// make sure a valid camera exists
	if (NULL == g_pCamera)
	{
		return;
	}

	// record the initial mouse location so the camera
	// does not jump during the first mouse movement
	if (gFirstMouse)
	{
		gLastX =
			static_cast<float>(xMousePos);

		gLastY =
			static_cast<float>(yMousePos);

		gFirstMouse = false;
	}

	// calculate mouse movement offsets
	float xOffset =
		static_cast<float>(xMousePos) - gLastX;

	float yOffset =
		gLastY - static_cast<float>(yMousePos);

	// save current mouse location
	gLastX =
		static_cast<float>(xMousePos);

	gLastY =
		static_cast<float>(yMousePos);

	// change camera orientation
	g_pCamera->ProcessMouseMovement(
		xOffset,
		yOffset);
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  Changes camera travel speed with the mouse wheel.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(
	GLFWwindow* window,
	double xOffset,
	double yOffset)
{
	// make sure a valid camera exists
	if (NULL == g_pCamera)
	{
		return;
	}

	// increase or decrease camera movement speed
	g_pCamera->MovementSpeed +=
		static_cast<float>(yOffset) * 0.5f;

	// prevent movement from becoming too slow
	if (g_pCamera->MovementSpeed < 0.5f)
	{
		g_pCamera->MovementSpeed = 0.5f;
	}

	// prevent movement from becoming excessively fast
	if (g_pCamera->MovementSpeed > 10.0f)
	{
		g_pCamera->MovementSpeed = 10.0f;
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  Processes keyboard input for navigation and projection.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// ESC closes the window
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(
			m_pWindow,
			true);
	}

	// make sure a valid camera exists
	if (NULL == g_pCamera)
	{
		return;
	}

	/********************************************************/
	/* FORWARD AND BACKWARD                                 */
	/********************************************************/

	// W moves the camera forward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			FORWARD,
			gDeltaTime);
	}

	// S moves the camera backward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			BACKWARD,
			gDeltaTime);
	}

	/********************************************************/
	/* LEFT AND RIGHT                                       */
	/********************************************************/

	// A moves the camera left
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			LEFT,
			gDeltaTime);
	}

	// D moves the camera right
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			RIGHT,
			gDeltaTime);
	}

	/********************************************************/
	/* UP AND DOWN                                          */
	/********************************************************/

	// Q moves the camera upward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			UP,
			gDeltaTime);
	}

	// E moves the camera downward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			DOWN,
			gDeltaTime);
	}

	/********************************************************/
	/* PROJECTION MODES                                     */
	/********************************************************/

	// P selects perspective projection
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}

	// O selects orthographic projection
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  Prepares the camera view and projection matrices.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// calculate frame timing for smooth camera movement
	float currentFrame =
		static_cast<float>(glfwGetTime());

	gDeltaTime =
		currentFrame - gLastFrame;

	gLastFrame =
		currentFrame;

	// process keyboard input
	ProcessKeyboardEvents();

	/********************************************************/
	/* ORTHOGRAPHIC VIEW                                    */
	/********************************************************/

	if (bOrthographicProjection)
	{
		// Look directly toward the object so the ground plane
		// is edge-on and not visible in orthographic mode.
		view = glm::lookAt(
			glm::vec3(
				0.0f,
				1.5f,
				12.0f),

			glm::vec3(
				0.0f,
				1.5f,
				0.0f),

			glm::vec3(
				0.0f,
				1.0f,
				0.0f));

		// Create a flat orthographic projection
		projection = glm::ortho(
			-6.0f,
			6.0f,
			-5.0f,
			5.0f,
			0.1f,
			100.0f);
	}

	/********************************************************/
	/* PERSPECTIVE VIEW                                     */
	/********************************************************/

	else
	{
		// use the movable camera
		view =
			g_pCamera->GetViewMatrix();

		// create perspective projection
		projection = glm::perspective(
			glm::radians(
				g_pCamera->Zoom),

			static_cast<GLfloat>(WINDOW_WIDTH) /
			static_cast<GLfloat>(WINDOW_HEIGHT),

			0.1f,
			100.0f);
	}

	// send matrices to the shader
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ViewName,
			view);

		m_pShaderManager->setMat4Value(
			g_ProjectionName,
			projection);

		m_pShaderManager->setVec3Value(
			"viewPosition",
			g_pCamera->Position);
	}
}