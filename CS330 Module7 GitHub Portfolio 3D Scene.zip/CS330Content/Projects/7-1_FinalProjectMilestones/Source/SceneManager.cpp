///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// manage the loading and rendering of 3D scenes
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// declaration of global variables and defines
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  Constructor for the SceneManager class.
 ***********************************************************/
SceneManager::SceneManager(
	ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize texture count
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  Destructor for the SceneManager class.
 ***********************************************************/
SceneManager::~SceneManager()
{
	// release texture resources
	DestroyGLTextures();

	m_pShaderManager = NULL;

	delete m_basicMeshes;

	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  Loads an image and creates an OpenGL texture.
 ***********************************************************/
bool SceneManager::CreateGLTexture(
	const char* filename,
	std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;

	GLuint textureID = 0;

	// flip texture images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	unsigned char* image =
		stbi_load(
			filename,
			&width,
			&height,
			&colorChannels,
			0);

	if (image)
	{
		std::cout
			<< "Successfully loaded image:"
			<< filename
			<< ", width:"
			<< width
			<< ", height:"
			<< height
			<< ", channels:"
			<< colorChannels
			<< std::endl;

		glGenTextures(
			1,
			&textureID);

		glBindTexture(
			GL_TEXTURE_2D,
			textureID);

		// texture wrapping parameters
		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_WRAP_S,
			GL_REPEAT);

		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_WRAP_T,
			GL_REPEAT);

		// texture filtering parameters
		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_MIN_FILTER,
			GL_LINEAR);

		glTexParameteri(
			GL_TEXTURE_2D,
			GL_TEXTURE_MAG_FILTER,
			GL_LINEAR);

		if (colorChannels == 3)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGB8,
				width,
				height,
				0,
				GL_RGB,
				GL_UNSIGNED_BYTE,
				image);
		}
		else if (colorChannels == 4)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGBA8,
				width,
				height,
				0,
				GL_RGBA,
				GL_UNSIGNED_BYTE,
				image);
		}
		else
		{
			std::cout
				<< "Not implemented to handle image with "
				<< colorChannels
				<< " channels"
				<< std::endl;

			stbi_image_free(image);

			return false;
		}

		// generate mipmaps
		glGenerateMipmap(
			GL_TEXTURE_2D);

		// release image memory
		stbi_image_free(image);

		glBindTexture(
			GL_TEXTURE_2D,
			0);

		// register texture
		m_textureIDs[m_loadedTextures].ID =
			textureID;

		m_textureIDs[m_loadedTextures].tag =
			tag;

		m_loadedTextures++;

		return true;
	}

	std::cout
		<< "Could not load image:"
		<< filename
		<< std::endl;

	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  Binds loaded textures to OpenGL texture slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0;
		i < m_loadedTextures;
		i++)
	{
		glActiveTexture(
			GL_TEXTURE0 + i);

		glBindTexture(
			GL_TEXTURE_2D,
			m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  Frees OpenGL texture memory.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0;
		i < m_loadedTextures;
		i++)
	{
		glDeleteTextures(
			1,
			&m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  Finds a loaded texture using its assigned tag.
 ***********************************************************/
int SceneManager::FindTextureID(
	std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while (
		(index < m_loadedTextures) &&
		(bFound == false))
	{
		if (
			m_textureIDs[index].tag.compare(tag)
			== 0)
		{
			textureID =
				m_textureIDs[index].ID;

			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureID;
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  Finds the texture slot associated with a tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(
	std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while (
		(index < m_loadedTextures) &&
		(bFound == false))
	{
		if (
			m_textureIDs[index].tag.compare(tag)
			== 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureSlot;
}

/***********************************************************
 *  FindMaterial()
 *
 *  Finds a material using its assigned tag.
 ***********************************************************/
bool SceneManager::FindMaterial(
	std::string tag,
	OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return false;
	}

	int index = 0;
	bool bFound = false;

	while (
		(index < m_objectMaterials.size()) &&
		(bFound == false))
	{
		if (
			m_objectMaterials[index].tag.compare(tag)
			== 0)
		{
			bFound = true;

			material.ambientColor =
				m_objectMaterials[index].ambientColor;

			material.ambientStrength =
				m_objectMaterials[index].ambientStrength;

			material.diffuseColor =
				m_objectMaterials[index].diffuseColor;

			material.specularColor =
				m_objectMaterials[index].specularColor;

			material.shininess =
				m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return bFound;
}

/***********************************************************
 *  SetTransformations()
 *
 *  Builds and sends the model matrix to the shader.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// scale
	scale =
		glm::scale(scaleXYZ);

	// rotations
	rotationX =
		glm::rotate(
			glm::radians(
				XrotationDegrees),

			glm::vec3(
				1.0f,
				0.0f,
				0.0f));

	rotationY =
		glm::rotate(
			glm::radians(
				YrotationDegrees),

			glm::vec3(
				0.0f,
				1.0f,
				0.0f));

	rotationZ =
		glm::rotate(
			glm::radians(
				ZrotationDegrees),

			glm::vec3(
				0.0f,
				0.0f,
				1.0f));

	// translation
	translation =
		glm::translate(
			positionXYZ);

	// build final model matrix
	modelView =
		translation *
		rotationX *
		rotationY *
		rotationZ *
		scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ModelName,
			modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  Sets the color used for the next object.
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor;

	currentColor.r =
		redColorValue;

	currentColor.g =
		greenColorValue;

	currentColor.b =
		blueColorValue;

	currentColor.a =
		alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			false);

		m_pShaderManager->setVec4Value(
			g_ColorValueName,
			currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  Selects a texture for the next object.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			true);

		int textureID =
			FindTextureSlot(
				textureTag);

		m_pShaderManager->setSampler2DValue(
			g_TextureValueName,
			textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  Sets texture coordinate scaling.
 ***********************************************************/
void SceneManager::SetTextureUVScale(
	float u,
	float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value(
			"UVscale",
			glm::vec2(
				u,
				v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  Sends material values to the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;

		bool bReturn =
			FindMaterial(
				materialTag,
				material);

		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value(
				"material.ambientColor",
				material.ambientColor);

			m_pShaderManager->setFloatValue(
				"material.ambientStrength",
				material.ambientStrength);

			m_pShaderManager->setVec3Value(
				"material.diffuseColor",
				material.diffuseColor);

			m_pShaderManager->setVec3Value(
				"material.specularColor",
				material.specularColor);

			m_pShaderManager->setFloatValue(
				"material.shininess",
				material.shininess);
		}
	}
}

// Define scene materials
void DefineSceneMaterials();

// Configure scene lights
void SetupSceneLights();

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/**************************************************************/

/***********************************************************
 *  PrepareScene()
 *
 *  Loads the textures and meshes needed for Milestone Four.
 ***********************************************************/
// Define basic Phong materials for the textured ground and pyramids.
// The plane uses a slightly more reflective surface for visible highlights.
void SceneManager::DefineMilestoneMaterials()
{
    m_objectMaterials.clear();

    OBJECT_MATERIAL ground;
    ground.tag = "ground";
    ground.ambientColor = glm::vec3(0.9f, 0.9f, 0.9f);
    ground.ambientStrength = 0.12f;
    ground.diffuseColor = glm::vec3(0.82f, 0.82f, 0.82f);
    ground.specularColor = glm::vec3(0.25f, 0.25f, 0.25f);
    ground.shininess = 28.0f;
    m_objectMaterials.push_back(ground);

    OBJECT_MATERIAL pyramid;
    pyramid.tag = "pyramid";
    pyramid.ambientColor = glm::vec3(0.9f, 0.9f, 0.9f);
    pyramid.ambientStrength = 0.14f;
    pyramid.diffuseColor = glm::vec3(0.90f, 0.90f, 0.90f);
    pyramid.specularColor = glm::vec3(0.24f, 0.24f, 0.24f);
    pyramid.shininess = 24.0f;
    m_objectMaterials.push_back(pyramid);
}

// Configure two point lights at different positions so every object is visible.
void SceneManager::SetupMilestoneLights()
{
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // Main warm-white light illuminates the front and textured floor.
    m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(-5.0f, 8.0f, 6.0f));
    m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.03f, 0.03f, 0.03f));
    m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(0.80f, 0.76f, 0.70f));
    m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(0.80f, 0.76f, 0.70f));
    m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 24.0f);
    m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.35f);

    // Cool secondary light softly fills areas on the opposite side.
    m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(5.0f, 6.0f, 4.0f));
    m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.01f, 0.01f, 0.02f));
    m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.48f, 0.55f, 0.68f));
    m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.50f, 0.58f, 0.72f));
    m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 20.0f);
    m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.22f);

    // Disable unused lights to prevent unexpected shading.
    for (int i = 2; i < 4; ++i)
    {
        std::string prefix = "lightSources[" + std::to_string(i) + "].";
        m_pShaderManager->setVec3Value(prefix + "ambientColor", glm::vec3(0.0f));
        m_pShaderManager->setVec3Value(prefix + "diffuseColor", glm::vec3(0.0f));
        m_pShaderManager->setVec3Value(prefix + "specularColor", glm::vec3(0.0f));
        m_pShaderManager->setFloatValue(prefix + "specularIntensity", 0.0f);
    }
}

void SceneManager::PrepareScene()
{
	// Load the three textures used in the scene.
	CreateGLTexture(
		"textures/stone.jpg",
		"stone");

	CreateGLTexture(
		"textures/brick.jpg",
		"brick");

	CreateGLTexture(
		"textures/metal.jpg",
		"metal");

	// Bind loaded textures to OpenGL texture slots.
	BindGLTextures();

	// Load the base plane.
	m_basicMeshes->LoadPlaneMesh();

	// Load the pyramid mesh used for both parts of the object.
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();

	// Apply Phong materials and activate the two scene lights.
	DefineMilestoneMaterials();
	SetupMilestoneLights();
}

/***********************************************************
 *  RenderScene()
 *
 *  Renders the textured plane and stacked pyramid object.
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;

	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;

	glm::vec3 positionXYZ;

	/********************************************************/
	/* BASE PLANE - TILED STONE TEXTURE                     */
	/********************************************************/

	scaleXYZ =
		glm::vec3(
			20.0f,
			1.0f,
			10.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			-1.8f,
			0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the stone texture to the plane.
	SetShaderMaterial("ground");
	SetShaderTexture(
		"stone");

	// Tile the stone texture across the large plane.
	SetTextureUVScale(
		6.0f,
		6.0f);

	m_basicMeshes->DrawPlaneMesh();

	/********************************************************/
	/* TOP PYRAMID - METAL TEXTURE                          */
	/********************************************************/

	scaleXYZ =
		glm::vec3(
			2.0f,
			1.7f,
			1.0f);

	// Tilt the top pyramid and flip it upside down.
	XrotationDegrees = -15.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 180.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			1.85f,
			0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply metal texture to the top component.
	SetShaderMaterial("pyramid");
	SetShaderTexture(
		"metal");

	SetTextureUVScale(
		1.0f,
		1.0f);

	m_basicMeshes->DrawPyramid4Mesh();

	/********************************************************/
	/* BOTTOM PYRAMID - BRICK TEXTURE                       */
	/********************************************************/

	scaleXYZ =
		glm::vec3(
			2.0f,
			1.7f,
			1.0f);

	// Tilt the bottom pyramid.
	XrotationDegrees = -15.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ =
		glm::vec3(
			0.0f,
			0.15f,
			0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply brick texture to the lower component.
	SetShaderMaterial("pyramid");
	SetShaderTexture(
		"brick");

	SetTextureUVScale(
		1.0f,
		1.0f);

	m_basicMeshes->DrawPyramid4Mesh();
	// Brick pedestal underneath the sculpture
	SetTransformations(
		glm::vec3(2.8f, 0.6f, 1.8f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, -1.5f, 0.0f));

	SetShaderMaterial("pyramid");
	SetShaderTexture("brick");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// Left metal column
	SetTransformations(
		glm::vec3(0.6f, 2.2f, 0.6f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-4.0f, -0.7f, 0.0f));

	SetShaderMaterial("pyramid");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Left decorative stone sphere
	SetTransformations(
		glm::vec3(0.8f, 0.8f, 0.8f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-4.0f, 0.8f, 0.0f));

	SetShaderMaterial("ground");
	SetShaderTexture("stone");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();

	// Right metal column
	SetTransformations(
		glm::vec3(0.6f, 2.2f, 0.6f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(4.0f, -0.7f, 0.0f));

	SetShaderMaterial("pyramid");
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Right decorative stone sphere
	SetTransformations(
		glm::vec3(0.8f, 0.8f, 0.8f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(4.0f, 0.8f, 0.0f));

	SetShaderMaterial("ground");
	SetShaderTexture("stone");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawSphereMesh();
}
