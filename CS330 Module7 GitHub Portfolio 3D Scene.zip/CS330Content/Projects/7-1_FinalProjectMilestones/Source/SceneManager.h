///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ==============
// manage the loading and rendering of 3D scenes
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(
		ShaderManager* pShaderManager);

	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;

	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;

	// total number of loaded textures
	int m_loadedTextures;

	// loaded texture information
	TEXTURE_INFO m_textureIDs[16];

	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	// load texture images into OpenGL
	bool CreateGLTexture(
		const char* filename,
		std::string tag);

	// bind loaded OpenGL textures
	void BindGLTextures();

	// free loaded OpenGL textures
	void DestroyGLTextures();

	// find loaded texture information
	int FindTextureID(std::string tag);

	int FindTextureSlot(std::string tag);

	// find a defined material
	bool FindMaterial(
		std::string tag,
		OBJECT_MATERIAL& material);

	// set transformation values
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set object color
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set object texture
	void SetShaderTexture(
		std::string textureTag);

	// set texture UV scale
	void SetTextureUVScale(
		float u,
		float v);

	// set object material
	void SetShaderMaterial(
		std::string materialTag);

	// Define scene materials
	void DefineSceneMaterials();

	// Configure scene lights
	void SetupSceneLights();

private:
	// Set up Phong materials and two lights for Milestone Five.
	void DefineMilestoneMaterials();
	void SetupMilestoneLights();

public:
	// student-customized scene methods
	void PrepareScene();

	void RenderScene();
};